import json
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import DataLoader
from .data import collate, model_inputs, PARAMETERS


def move_batch(batch, device):
    return {k: v.to(device, non_blocking=True) if torch.is_tensor(v) else v for k, v in batch.items()}


def summarize(records, codec):
    result = {"samples": len(records), "filtered": False, "parameters": {}}
    if not records:
        raise ValueError("Empty evaluation")
    z = np.array([r["prediction_z"] for r in records])
    target = np.array([r["target_z"] for r in records])
    valid = np.array([r["target_mask"] for r in records], bool)
    std = np.array(codec.stats["std"])
    means = np.array(codec.stats["mean"])
    pred_raw = codec.decode(torch.tensor(z)).numpy()
    gt_raw = codec.decode(torch.tensor(target)).numpy()
    scores = []
    for j, name in enumerate(PARAMETERS):
        mask = valid[:, j]
        x, y = z[mask, j] * std[j] + means[j], target[mask, j] * std[j] + means[j]
        if not len(x):
            result["parameters"][name] = {"count": 0}
            continue
        ae = np.abs(x - y)
        raw_ae = np.abs(pred_raw[mask, j] - gt_raw[mask, j])
        denom = ((y - y.mean()) ** 2).sum()
        variance = np.exp(np.array([r["logvar"] for r in records])[mask, j]) * std[j] ** 2
        coverage = np.mean(ae <= 1.96 * np.sqrt(variance))
        scores.extend(np.abs(z[mask, j] - target[mask, j]).tolist())
        result["parameters"][name] = {
            "count": int(mask.sum()), "transformed_mae": float(ae.mean()),
            "transformed_median_ae": float(np.median(ae)), "transformed_p90_ae": float(np.quantile(ae, .9)),
            "raw_mae": float(raw_ae.mean()), "raw_median_ae": float(np.median(raw_ae)),
            "r2": float(1 - ((x-y)**2).sum()/denom) if denom > 0 else None,
            "pearson": float(np.corrcoef(x,y)[0,1]) if len(x)>1 and x.std()>0 and y.std()>0 else None,
            "nominal_95_coverage_transformed": float(coverage)}
    result["standardized_mae"] = float(np.mean(scores)) if scores else None
    result["note"] = "Train-standardized ln1p/linear errors; raw outputs are constrained; not the legacy SPE. Coverage is empirical, not guaranteed."
    return result


@torch.no_grad()
def evaluate(model, dataset, device, output=None, batch_size=1):
    model.eval()
    records = []
    field_num, field_den = 0., 0.
    for batch in DataLoader(dataset, batch_size=batch_size, shuffle=False, collate_fn=collate):
        batch = move_batch(batch, device)
        prediction = model(**model_inputs(batch))
        err = (prediction["fields"] - batch["fields"]).abs() * batch["field_mask"]
        field_num += err.sum().item()
        field_den += batch["field_mask"].sum().item()
        for i, sid in enumerate(batch["sample_id"]):
            records.append({"sample_id": sid, "object_id": batch["object_id"][i], "source": batch["source"][i],
                            "action": batch["action"][i], "law_id": batch["law"][i].item(),
                            "prediction_z": prediction["mean"][i].float().cpu().tolist(),
                            "logvar": prediction["logvar"][i].float().cpu().tolist(),
                            "target_z": batch["target"][i].cpu().tolist(),
                            "target_mask": batch["target_mask"][i].cpu().tolist()})
    result = summarize(records, dataset.codec)
    result["field_absolute_error_encoded"] = field_num / field_den if field_den else None
    result["by_source"] = {s: summarize([r for r in records if r["source"] == s], dataset.codec)
                           for s in sorted({r["source"] for r in records})}
    result["by_action"] = {s: summarize([r for r in records if r["action"] == s], dataset.codec)
                           for s in sorted({r["action"] for r in records})}
    result["by_law"] = {str(s): summarize([r for r in records if r["law_id"] == s], dataset.codec)
                        for s in sorted({r["law_id"] for r in records})}
    if output:
        output = Path(output)
        output.mkdir(parents=True, exist_ok=True)
        (output / "summary.json").write_text(json.dumps(result, indent=2, allow_nan=False))
        (output / "predictions.jsonl").write_text("".join(json.dumps(r) + "\n" for r in records))
    return result
