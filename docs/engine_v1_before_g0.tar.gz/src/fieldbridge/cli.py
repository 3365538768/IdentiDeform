import argparse
import json
from pathlib import Path
import torch
from .config import load_config
from .data import read_manifest, fit_stats, MaterialDataset
from .evaluation import evaluate
from .model import MaterialFieldModel


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    audit = sub.add_parser("audit")
    audit.add_argument("manifest")
    stats = sub.add_parser("fit-stats")
    stats.add_argument("manifest"); stats.add_argument("output")
    ev = sub.add_parser("evaluate")
    ev.add_argument("--config", required=True); ev.add_argument("--checkpoint", required=True)
    ev.add_argument("--split", choices=["val", "test"], default="val")
    ev.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.command == "fit-stats":
        print(json.dumps(fit_stats(args.manifest, args.output), indent=2))
    elif args.command == "audit":
        rows = read_manifest(args.manifest)
        missing = [r["sample_id"] for r in rows if not Path(r["pack"]).is_file()]
        if missing:
            raise FileNotFoundError(str(missing[:20]))
        print(json.dumps({"samples": len(rows), "splits": {s: sum(r["split"] == s for r in rows) for s in ("train", "val", "test")},
                          "objects": len({(r["source"], r["object_id"]) for r in rows}), "leakage": False}))
    else:
        cfg = load_config(args.config)
        device = torch.device(cfg.train.device)
        dataset = MaterialDataset(cfg.data, args.split, cfg.model.field_size, cfg.model.field_mode)
        ckpt = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
        if ckpt["stats"] != dataset.codec.stats or ckpt["config"]["model"] != cfg.dump()["model"]:
            raise ValueError("Evaluation checkpoint/config/statistics mismatch")
        model = MaterialFieldModel(cfg.model).to(device)
        model.load_state_dict(ckpt["model"], strict=True)
        print(json.dumps(evaluate(model, dataset, device, args.output), indent=2))


if __name__ == "__main__":
    main()
