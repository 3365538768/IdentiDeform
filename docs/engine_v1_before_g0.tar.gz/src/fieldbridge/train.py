"""Single-GPU or torchrun DDP trainer. Validation never reads test samples."""
import argparse
from contextlib import nullcontext
from datetime import timedelta
from pathlib import Path
import hashlib
import json
import os
import random
import time
import numpy as np
import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader, DistributedSampler
from .config import load_config
from .data import MaterialDataset, collate, model_inputs
from .evaluation import evaluate, move_batch
from .losses import compute_loss
from .model import MaterialFieldModel


def atomic_save(obj, path):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(obj, temporary)
    os.replace(temporary, path)


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(8 * 1024**2), b""):
            digest.update(block)
    return digest.hexdigest()


def rng_state():
    state = {"python": random.getstate(), "numpy": np.random.get_state(), "torch": torch.get_rng_state()}
    if torch.cuda.is_available():
        state["cuda"] = torch.cuda.get_rng_state()
    return state


def restore_rng(state):
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"].cpu())
    if "cuda" in state:
        torch.cuda.set_rng_state(state["cuda"].cpu())


def run(config_path):
    cfg = load_config(config_path)
    world, rank = int(os.environ.get("WORLD_SIZE", 1)), int(os.environ.get("RANK", 0))
    local_rank = int(os.environ.get("LOCAL_RANK", 0))
    if cfg.train.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable; no silent CPU fallback")
    device = torch.device(f"cuda:{local_rank}" if cfg.train.device == "cuda" else "cpu")
    if device.type == "cuda":
        torch.cuda.set_device(device)
    if world > 1:
        extra = {"device_id": device} if device.type == "cuda" else {}
        dist.init_process_group("nccl" if device.type == "cuda" else "gloo", timeout=timedelta(minutes=30), **extra)
    seed = cfg.train.seed + rank
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    train = MaterialDataset(cfg.data, "train", cfg.model.field_size, cfg.model.field_mode)
    val = MaterialDataset(cfg.data, "val", cfg.model.field_size, cfg.model.field_mode)
    if cfg.model.use_prior and not any(r.get("prior_parameters") for r in train.rows):
        raise ValueError("Prior experiment requested but no independent static predictions were supplied")
    out = Path(cfg.train.output)
    if rank == 0:
        out.mkdir(parents=True, exist_ok=True)
        if (out / "last.pt").exists() and not cfg.train.resume:
            raise FileExistsError("Use a new output directory or explicitly resume")
    sampler = DistributedSampler(train, shuffle=True, seed=cfg.train.seed) if world > 1 else None
    # Independent generator prevents validation or logging from changing train order.
    generator = torch.Generator().manual_seed(seed)
    loader = DataLoader(train, batch_size=cfg.train.batch_size, sampler=sampler, shuffle=sampler is None,
                        num_workers=cfg.train.workers, collate_fn=collate, pin_memory=device.type == "cuda",
                        generator=generator)
    raw_model = MaterialFieldModel(cfg.model).to(device)
    if cfg.train.initialize:
        initial = torch.load(cfg.train.initialize, map_location="cpu", weights_only=False)
        raw_model.load_state_dict(initial["model"], strict=True)
    backbone_params, head_params = [], []
    for name, parameter in raw_model.named_parameters():
        if parameter.requires_grad:
            (backbone_params if name.startswith("frame_encoder.") else head_params).append(parameter)
    groups = [{"params": head_params, "lr": cfg.train.lr}]
    if backbone_params:
        groups.append({"params": backbone_params, "lr": cfg.train.backbone_lr})
    optimizer = torch.optim.AdamW(groups, weight_decay=cfg.train.weight_decay)
    model = DDP(raw_model, device_ids=[local_rank] if device.type == "cuda" else None,
                broadcast_buffers=False) if world > 1 else raw_model
    start_epoch, step, best = 0, 0, float("inf")
    manifest_hash = hashlib.sha256(Path(cfg.data.manifest).read_bytes()).hexdigest()
    if cfg.train.resume:
        checkpoint = torch.load(cfg.train.resume, map_location="cpu", weights_only=False)
        if checkpoint["manifest_sha256"] != manifest_hash or checkpoint["config"]["model"] != cfg.dump()["model"]:
            raise ValueError("Resume data/model mismatch")
        if checkpoint["world_size"] != world:
            raise ValueError("Exact resume requires the same world size")
        # Resume supports epoch boundaries only, so partially completed smoke runs cannot be resumed.
        if not checkpoint.get("epoch_complete", False):
            raise ValueError("Partial-epoch checkpoint is initialization-only, not exact resume")
        raw_model.load_state_dict(checkpoint["model"])
        optimizer.load_state_dict(checkpoint["optimizer"])
        start_epoch, step, best = checkpoint["epoch"] + 1, checkpoint["step"], checkpoint["best"]
        restore_rng(checkpoint["rng_states"][rank])
        generator.set_state(checkpoint["loader_states"][rank])
    if rank == 0:
        source_digest = hashlib.sha256()
        for source_file in sorted(Path(__file__).parent.glob("*.py")):
            source_digest.update(source_file.name.encode())
            source_digest.update(source_file.read_bytes())
        provenance = {"config": cfg.dump(), "manifest_sha256": manifest_hash, "stats": train.codec.stats,
                      "source_sha256": source_digest.hexdigest(),
                      "backbone_checkpoint_sha256": file_sha256(cfg.model.weights) if cfg.model.weights else None,
                      "torch": torch.__version__, "world_size": world,
                      "parameters": sum(p.numel() for p in raw_model.parameters()),
                      "trainable_parameters": sum(p.numel() for p in raw_model.parameters() if p.requires_grad),
                      "software_check_only": cfg.model.backbone == "tiny" or cfg.train.purpose == "smoke",
                      "purpose": cfg.train.purpose,
                      "time_unix": time.time()}
        (out / "run.json").write_text(json.dumps(provenance, indent=2))
        print(json.dumps({k: provenance[k] for k in ("parameters", "trainable_parameters", "world_size", "software_check_only")}), flush=True)
    amp = cfg.train.bf16 and device.type == "cuda"
    for epoch in range(start_epoch, cfg.train.epochs):
        if sampler:
            sampler.set_epoch(epoch)
        model.train()
        optimizer.zero_grad(set_to_none=True)
        complete = True
        for i, batch in enumerate(loader):
            batch = move_batch(batch, device)
            group_start = (i // cfg.train.accumulation) * cfg.train.accumulation
            group_length = min(cfg.train.accumulation, len(loader) - group_start)
            sync = (i + 1) % cfg.train.accumulation == 0 or i + 1 == len(loader)
            ctx = model.no_sync() if world > 1 and not sync else nullcontext()
            with ctx:
                with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=amp):
                    prediction = model(**model_inputs(batch))
                    loss, components = compute_loss(prediction, batch, cfg, field_only=epoch < cfg.train.field_epochs)
                if not torch.isfinite(loss):
                    raise FloatingPointError("Non-finite loss")
                (loss / group_length).backward()
            if sync:
                norm = torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.train.clip_grad)
                if not torch.isfinite(norm):
                    raise FloatingPointError("Non-finite gradient")
                optimizer.step(); optimizer.zero_grad(set_to_none=True)
                step += 1
                if rank == 0:
                    record = {"epoch": epoch, "step": step, "loss_rank0": loss.item(),
                              **{k: x.item() for k, x in components.items()}}
                    with (out / "train.jsonl").open("a") as f:
                        f.write(json.dumps(record) + "\n")
                    if step <= 3 or step % 20 == 0:
                        print(json.dumps(record), flush=True)
                if cfg.train.max_steps and step >= cfg.train.max_steps:
                    complete = i + 1 == len(loader)
                    break
        if world > 1:
            dist.barrier()
        improved = False
        if rank == 0:
            metrics = evaluate(raw_model, val, device, out / f"val_epoch_{epoch:04d}")
            score = metrics["standardized_mae"]
            if score is not None and score < best:
                best, improved = score, True
            print(json.dumps({"epoch": epoch, "val_standardized_mae": score}), flush=True)
        states, loader_states = [None] * world, [None] * world
        if world > 1:
            dist.all_gather_object(states, rng_state())
            dist.all_gather_object(loader_states, generator.get_state())
        else:
            states, loader_states = [rng_state()], [generator.get_state()]
        if rank == 0:
            checkpoint = {"model": raw_model.state_dict(), "optimizer": optimizer.state_dict(),
                          "config": cfg.dump(), "manifest_sha256": manifest_hash, "stats": train.codec.stats,
                          "epoch": epoch, "epoch_complete": complete, "step": step, "best": best,
                          "world_size": world, "rng_states": states, "loader_states": loader_states}
            atomic_save(checkpoint, out / "last.pt")
            if improved:
                atomic_save(checkpoint, out / "best.pt")
        if world > 1:
            dist.barrier()
        if cfg.train.max_steps and step >= cfg.train.max_steps:
            break
    if rank == 0:
        status = {"status": "software_smoke_passed" if cfg.model.backbone == "tiny" or cfg.train.purpose == "smoke" else "engineering_pilot_finished" if cfg.train.purpose == "pilot" else "training_finished",
                  "steps": step, "best_val_standardized_mae": best,
                  "max_gpu_allocated_bytes": torch.cuda.max_memory_allocated(device) if device.type == "cuda" else 0}
        (out / "status.json").write_text(json.dumps(status, indent=2))
    if world > 1:
        dist.destroy_process_group()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    run(parser.parse_args().config)
